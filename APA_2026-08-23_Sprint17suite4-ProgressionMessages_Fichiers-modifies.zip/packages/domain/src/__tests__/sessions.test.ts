import { describe, expect, it } from "vitest";
import { DIFFICULTY_LEVELS, DIFFICULTY_LABELS_FR, SESSION_STATUSES, computeProgressionFacts, type Session } from "../sessions";

describe("DIFFICULTY_LEVELS (§69 — feedback après séance)", () => {
  it("couvre les quatre niveaux repris du cahier des charges", () => {
    expect(DIFFICULTY_LEVELS).toEqual(["facile", "adaptee", "difficile", "tres_difficile"]);
  });

  it("chaque niveau a un libellé FR", () => {
    for (const level of DIFFICULTY_LEVELS) {
      expect(DIFFICULTY_LABELS_FR[level]).toBeTruthy();
    }
  });
});

describe("SESSION_STATUSES", () => {
  it("couvre le cycle de vie in_progress -> completed | abandoned", () => {
    expect(SESSION_STATUSES).toEqual(["in_progress", "completed", "abandoned"]);
  });
});

function makeSession(overrides: Partial<Session> & { startedAt: string }): Session {
  return {
    id: "session-fixture",
    userId: "user-fixture",
    pathology: "LOMBALGIE_COMMUNE",
    status: "completed",
    createdAt: overrides.startedAt,
    ...overrides,
  };
}

/**
 * §29, §58, §70 ; Sprint 17 (suite 4, 23/08/2026). `computeProgressionFacts`
 * ne doit dériver QUE ce que Dr Nikiema a explicitement chiffré (B2, B9) —
 * jamais une clé pour ce qui reste non chiffré (fatigue excessive, signal
 * isolé/répété, gonflement/raideur, baisse fonctionnelle).
 */
describe("computeProgressionFacts (§29, §58, §70, réponses B2/B9 du 20/08/2026)", () => {
  it("aucune séance, pas d'adhésion connue -> aucun fait", () => {
    expect(computeProgressionFacts([], null)).toEqual({});
  });

  it("transmet le taux d'adhésion de la semaine si fourni", () => {
    expect(computeProgressionFacts([], 85)).toEqual({ adherence_percent_semaine: 85 });
  });

  it("reprend fidèlement les champs de la dernière séance quand ils sont renseignés", () => {
    const last = makeSession({ startedAt: "2026-08-23T08:00:00Z", realisee: true, douleurApres: 2, fatigueApres: 4, difficulte: "adaptee" });
    const facts = computeProgressionFacts([last], null);
    expect(facts).toEqual({
      derniere_seance_realisee: true,
      douleur_apres_derniere_seance: 2,
      fatigue_apres_derniere_seance: 4,
      difficulte_derniere_seance: "adaptee",
    });
  });

  it("n'invente aucune clé pour un champ de la dernière séance non renseigné", () => {
    const last = makeSession({ startedAt: "2026-08-23T08:00:00Z" });
    const facts = computeProgressionFacts([last], null);
    expect(facts).toEqual({});
  });

  it("détecte une aggravation persistante au-delà de 24h (douleur > 3/10 aux deux bouts, ≥ 24h d'écart)", () => {
    const previous = makeSession({ startedAt: "2026-08-20T08:00:00Z", douleurApres: 5 });
    const last = makeSession({ startedAt: "2026-08-21T09:00:00Z", douleurAvant: 4 }); // 25h plus tard
    const facts = computeProgressionFacts([last, previous], null);
    expect(facts.douleur_aggravation_persistante_24h).toBe(true);
  });

  it("pas d'aggravation persistante si la douleur est revenue à 3/10 ou moins (seuil B2)", () => {
    const previous = makeSession({ startedAt: "2026-08-20T08:00:00Z", douleurApres: 5 });
    const last = makeSession({ startedAt: "2026-08-21T09:00:00Z", douleurAvant: 3 }); // retour au seuil tolérable
    const facts = computeProgressionFacts([last, previous], null);
    expect(facts.douleur_aggravation_persistante_24h).toBe(false);
  });

  it("ne calcule pas l'aggravation persistante si les deux séances sont espacées de moins de 24h", () => {
    const previous = makeSession({ startedAt: "2026-08-20T08:00:00Z", douleurApres: 6 });
    const last = makeSession({ startedAt: "2026-08-20T20:00:00Z", douleurAvant: 6 }); // 12h plus tard seulement
    const facts = computeProgressionFacts([last, previous], null);
    expect(facts.douleur_aggravation_persistante_24h).toBeUndefined();
  });

  it("ne calcule pas l'aggravation persistante si une seule séance est disponible", () => {
    const last = makeSession({ startedAt: "2026-08-23T08:00:00Z", douleurAvant: 6 });
    const facts = computeProgressionFacts([last], null);
    expect(facts.douleur_aggravation_persistante_24h).toBeUndefined();
  });

  it("n'introduit jamais de clé pour ce que les réponses B2/B9 ne chiffrent pas (fatigue excessive, répétition, gonflement, fonctionnel)", () => {
    const last = makeSession({ startedAt: "2026-08-23T08:00:00Z", realisee: true, douleurApres: 1, fatigueApres: 9, difficulte: "tres_difficile" });
    const facts = computeProgressionFacts([last], 90);
    const keys = Object.keys(facts);
    expect(keys).not.toContain("fatigue_excessive");
    expect(keys).not.toContain("symptomes_repetes");
    expect(keys).not.toContain("gonflement");
    expect(keys).not.toContain("raideur");
    expect(keys).not.toContain("baisse_fonctionnelle");
  });
});
