import type { PathologyCode } from "./pathologies";
import type { Facts } from "./rules";

/**
 * §69 « Feedback après séance » : les quatre niveaux de difficulté ressentie
 * proposés au patient à la clôture. Repris tel quel du cahier des charges —
 * aucun seuil numérique associé n'est inventé ici (voir
 * docs/MEDICAL_VALIDATION_NEEDED.md pour ce qui reste à valider en aval,
 * ex. règles de progression/régression, Sprint 8).
 */
export const DIFFICULTY_LEVELS = ["facile", "adaptee", "difficile", "tres_difficile"] as const;
export type DifficultyLevel = (typeof DIFFICULTY_LEVELS)[number];

export const DIFFICULTY_LABELS_FR: Record<DifficultyLevel, string> = {
  facile: "Facile",
  adaptee: "Adaptée",
  difficile: "Difficile",
  tres_difficile: "Très difficile",
};

export const SESSION_STATUSES = ["in_progress", "completed", "abandoned"] as const;
export type SessionStatus = (typeof SESSION_STATUSES)[number];

/** Reflète la table `sessions` (§28, §69, Sprint 7). */
export interface Session {
  id: string;
  userId: string;
  programId?: string | null;
  pathology: PathologyCode;
  status: SessionStatus;
  douleurAvant?: number | null;
  fatigueAvant?: number | null;
  etatGeneralAvant?: string | null;
  realisee?: boolean | null;
  difficulte?: DifficultyLevel | null;
  douleurApres?: number | null;
  fatigueApres?: number | null;
  ressenti?: string | null;
  startedAt: string;
  completedAt?: string | null;
  createdAt: string;
}

/** Ligne de `session_exercises` (§28 étape 4) — exercices figés au démarrage
 * de la séance, indépendamment d'une évolution ultérieure du programme. */
export interface SessionExercise {
  sessionId: string;
  exerciseId: string;
  orderIndex: number;
  completed: boolean;
}

/**
 * Seuil de « douleur d'exercice » tolérable, tel que chiffré explicitement
 * par Dr Nikiema le 20/08/2026 (réf. B2 : « douleur d'exercice ≤ 3/10 sans
 * aggravation durable » comme critère de progression). Réutilisé ici tel
 * quel, jamais un nouveau seuil inventé — voir `computeProgressionFacts`
 * ci-dessous.
 */
export const EXERCISE_PAIN_TOLERABLE_THRESHOLD = 3;

/**
 * Dérive des faits de progression/régression (§29, §58, §70) à partir d'un
 * historique de séances déjà enregistré et du taux d'adhésion de la
 * semaine (déjà calculé par `computeAdherencePercent`, `statistics.ts`,
 * Sprint 9) — fonction pure, aucune décision clinique prise ici (§57,
 * §59 : ne jamais inventer une donnée médicale).
 *
 * Sprint 17 (suite 4, 23/08/2026) : construit strictement à partir de ce
 * que Dr Nikiema a explicitement chiffré dans ses réponses B2 (adhésion
 * ≥ 80 %, douleur d'exercice ≤ 3/10, retour au niveau habituel sous 24h)
 * et B9 (aggravation de la douleur au-delà de 24h = signal de régression).
 * Reste volontairement silencieux (clé absente du résultat plutôt qu'une
 * valeur devinée) sur tout ce que ces réponses ne chiffrent pas encore :
 * seuil de « fatigue excessive », distinction signal isolé/répété,
 * gonflement/raideur et baisse fonctionnelle (non trackés par `sessions`
 * ni `measurements` à ce jour) — voir
 * `QUESTIONS_PROGRESSION_REGRESSION_20260823.docx`.
 *
 * AUCUNE règle `adjust_progression` n'est encore seedée en base et cette
 * fonction n'est encore appelée depuis aucune route : elle prépare le
 * terrain pour quand ces règles existeront, sans rien décider elle-même.
 *
 * `recentSessions` doit être trié de la plus récente à la plus ancienne
 * (ex. `.order("started_at", { ascending: false })`), séances `completed`
 * de préférence — au moins la dernière séance ; les deux dernières sont
 * nécessaires pour la détection d'aggravation persistante au-delà de 24h.
 */
export function computeProgressionFacts(recentSessions: Session[], adherencePercentThisWeek: number | null | undefined): Facts {
  const facts: Record<string, boolean | number | string> = {};

  if (typeof adherencePercentThisWeek === "number") {
    facts.adherence_percent_semaine = adherencePercentThisWeek;
  }

  const [last, previous] = recentSessions;

  if (last) {
    if (typeof last.realisee === "boolean") facts.derniere_seance_realisee = last.realisee;
    if (typeof last.douleurApres === "number") facts.douleur_apres_derniere_seance = last.douleurApres;
    if (typeof last.fatigueApres === "number") facts.fatigue_apres_derniere_seance = last.fatigueApres;
    if (last.difficulte) facts.difficulte_derniere_seance = last.difficulte;
  }

  // B9 : « aggravation de la douleur au-delà de 24h ». Compare la douleur
  // ressentie à la FIN de l'avant-dernière séance (`previous.douleurApres`)
  // à celle ressentie au DÉBUT de la dernière séance (`last.douleurAvant`),
  // uniquement si celle-ci a démarré au moins 24h après le début de la
  // précédente. Seuil réutilisé : > 3/10 (EXERCISE_PAIN_TOLERABLE_THRESHOLD),
  // exactement la valeur donnée par Dr Nikiema pour la douleur d'exercice
  // tolérable (B2) — pas un nouveau seuil inventé.
  if (last && previous && typeof previous.douleurApres === "number" && typeof last.douleurAvant === "number") {
    const hoursBetween = (new Date(last.startedAt).getTime() - new Date(previous.startedAt).getTime()) / 3_600_000;
    if (hoursBetween >= 24) {
      facts.douleur_aggravation_persistante_24h =
        previous.douleurApres > EXERCISE_PAIN_TOLERABLE_THRESHOLD && last.douleurAvant > EXERCISE_PAIN_TOLERABLE_THRESHOLD;
    }
  }

  return facts;
}
