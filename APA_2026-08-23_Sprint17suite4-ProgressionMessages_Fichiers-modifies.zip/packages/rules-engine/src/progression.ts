import type { ClinicalRule, Facts, PathologyCode } from "@apa/domain";
import { MEDICAL_PARAMETER_REQUIRED } from "./constants";
import { evaluateRules } from "./engine";

/**
 * Décision de progression (§29, §58, §70) — Sprint 8 (squelette), complété
 * Sprint 17 (suite 4, 23/08/2026).
 *
 * Le cahier des charges donne la STRUCTURE :
 *   SI adhésion >= seuil ET tolérance = bonne ET progression = favorable
 *   ALORS proposer niveau supérieur
 * Les seuils eux-mêmes viennent des règles `clinical_rules` (action
 * `adjust_progression`, colonne `progression_decision` — migration 0013),
 * jamais codés en dur ici. §70 reste impératif : « Ne jamais augmenter
 * automatiquement la difficulté sur la seule base de la présence de
 * l'utilisateur » — c'est pourquoi une règle qui matche mais ne porte
 * AUCUNE `progressionDecision` est ignorée plutôt que de retomber sur une
 * valeur par défaut devinée (même principe que `programId` pour
 * `allow_program`, §57/§59/§78).
 *
 * Note de portée (23/08/2026) : ce module sait désormais évaluer des règles
 * réelles, mais AUCUNE règle `adjust_progression` n'est encore seedée en
 * base, et cette fonction n'est encore appelée depuis aucune route
 * (contrairement à `evaluateProgramAssignment`, câblé dans
 * apps/web/src/app/api/assessments/route.ts) : les critères B2/B9 déjà
 * répondus par Dr Nikiema ne couvrent pas encore tout ce qu'il faudrait
 * pour écrire ces règles sans inventer (fenêtre d'évaluation, distinction
 * signal isolé/répété, seuil de « fatigue excessive », gonflement/raideur/
 * baisse fonctionnelle non trackés) — voir
 * `QUESTIONS_PROGRESSION_REGRESSION_20260823.docx` et
 * `packages/domain/src/sessions.ts` (`computeProgressionFacts`).
 */
export type ProgressionDecision = "progress" | "maintain" | "reduce" | "suspend" | typeof MEDICAL_PARAMETER_REQUIRED;

export interface ProgressionResult {
  decision: ProgressionDecision;
  matchedRuleId?: string;
}

export function evaluateProgressionDecision(
  pathology: PathologyCode,
  facts: Facts,
  rules: ClinicalRule[]
): ProgressionResult {
  const matched = evaluateRules(
    rules.filter((rule) => rule.pathology === pathology && rule.action === "adjust_progression"),
    facts
  );

  // Une règle qui matche mais ne porte aucune décision explicite est
  // ignorée : on ne devine jamais (§57, §59, §78). `evaluateRules` trie
  // déjà par sévérité décroissante — la première règle porteuse d'une
  // décision est donc la plus prioritaire.
  const decided = matched.find((rule) => Boolean(rule.progressionDecision));

  if (!decided || !decided.progressionDecision) {
    return { decision: MEDICAL_PARAMETER_REQUIRED };
  }

  return { decision: decided.progressionDecision, matchedRuleId: decided.ruleId };
}
