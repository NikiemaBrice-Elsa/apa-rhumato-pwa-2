# Feuille de route — ce qu'il reste avant une application pleinement fonctionnelle

Photographie au 21/08/2026. Le détail ligne par ligne reste à jour dans `docs/MEDICAL_VALIDATION_NEEDED.md` (contenu médical) et `docs/DECISIONS.md` (choix techniques, section « Ce qui n'est toujours pas fait » de chaque sprint) — ce document en est une synthèse organisée par priorité, pour répondre à « qu'est-ce qui reste, concrètement ».

## 1. Ce qui bloque aujourd'hui l'attribution d'un programme réel à un patient

C'est le point le plus important : même avec un dépistage vert fonctionnel, aucun patient ne reçoit aujourd'hui de programme concret, faute de trois éléments liés entre eux.

- **Bibliothèque d'exercices** : 8 exercices sourcés sur la littérature citée au §81, complétés par des propositions génériques (ACSM/Borg) explicitement demandées par vous. **Mise à jour du 23/08 (intégration) : validés et activés** (« Je valide. Tu peux les intégrer », `infra/db/seed/0011_exercises_validation_dr_nikiema_20260823.sql`) — `medical_validation_status = 'validated'`, désormais visibles côté client authentifié.
- **Contenu des programmes** : chaque combinaison pathologie × niveau (débutant/intermédiaire/avancé) a désormais une fiche FITT-VP complète (fréquence, intensité, temps, type, volume, progression), rédigée à partir des 10 références du §81 et complétée par des propositions génériques que vous avez explicitement demandées et validées. **Mise à jour du 23/08 (intégration) : les 18 programmes sont validés et activés** (`infra/db/seed/0012_programs_validation_dr_nikiema_20260823.sql`) — `medical_validation_status = 'validated'`, désormais visibles côté client authentifié.
- **Règles d'attribution (`allow_program`)** : le moteur qui décide quel programme proposer selon le dépistage, le niveau et la douleur est prêt et testé, mais aucune règle réelle n'existe encore en base. **Mise à jour du 23/08 (suite) : chantier amorcé, mais bloqué sur 2 points précis** que votre réponse B4 ne tranche pas encore — voir `QUESTIONS_ALLOW_PROGRAM_20260823.docx` (2 questions courtes, propositions A/B à cocher). Sans ces 2 réponses, écrire des règles reviendrait à inventer un critère de tri clinique, ce qui n'est jamais fait sans votre autorisation explicite.

Les deux premiers éléments sont désormais en place et validés (23/08/2026) ; le troisième (règles d'attribution) reste le seul chaînon manquant avant qu'un patient puisse recevoir un programme réel — 2 questions courtes de votre part suffisent à le débloquer.

## 2. Sécurité du dépistage — ce qui reste ouvert

Le dépistage de sécurité (vert/orange/rouge) est aujourd'hui fonctionnel pour les six pathologies. Il reste deux choses, plus légères :

- **Relecture formelle des nouveaux messages** (issus de vos réponses Q2 à Q6, 21/08/2026) : rédigés selon vos principes habituels, mais pas encore soumis à une relecture dédiée comme le brouillon C1/B12 du 20/08. Je peux la préparer si vous le souhaitez.
- **Règles de progression/régression réelles** (`adjust_progression`) : vous avez répondu aux principes (réf. B2, progression ; B9, régression), mais ils ne sont pas encore traduits en règles actives — le mécanisme existe (`evaluateProgressionDecision`) et attend son contenu.

## 3. Fonctionnalités que vous avez déjà décrites, mais qui demandent du développement (pas seulement des règles)

Ces quatre points ont chacun une réponse de votre part, mais nécessitent une évolution du produit (nouveaux écrans, nouveaux champs de base de données), pas seulement l'ajout de contenu :

- **Structure de séance** (échauffement / partie principale / retour au calme, réf. B8) : la répartition en pourcentages est connue, mais aucun champ ne porte encore ce découpage et l'écran de séance affiche toujours les exercices d'un seul bloc.
- **Capacité fonctionnelle** (PROMIS Physical Function + PSFS, réf. B10) : les instruments à utiliser sont identifiés, mais pas encore intégrés à l'application.
- **« Séance du jour » planifiée** (réf. B11) : aujourd'hui, le tableau de bord renvoie simplement vers « Démarrer une séance », sans planification automatique ni fenêtre de réalisation. Cette fonctionnalité conditionne aussi une partie des cadences de notification que vous avez données (réf. B14).
- **Nouvelle formule d'adhésion** (réf. B13) : nécessite d'abord de faire évoluer le schéma des séances pour distinguer commencée / partielle / complète / reportée / annulée pour raison de sécurité.

## 4. Fonctionnalités prévues par le cahier des charges mais volontairement pas activées en V1

- Espace professionnel de santé pour consulter les rapports (§41) — prévu, pas encore ouvert.
- Envoi du rapport PDF par email, et historique des rapports déjà générés (aujourd'hui, chaque génération est à la demande, rien n'est conservé).
- Envoi réel de notifications push (aujourd'hui, les notifications existent uniquement dans l'application, pas en dehors).
- Passerelle de paiement réelle — le mécanisme actuel est une réconciliation manuelle (le patient transfère via Mobile Money et déclare la référence, un administrateur vérifie et confirme).
- Verrouillage de fonctionnalités derrière l'abonnement Premium — décision produit encore en attente de votre part, rien n'est verrouillé aujourd'hui.

## 5. Mise en production — indépendant du contenu médical

Ce sont des étapes techniques, à faire une fois que vous jugez le contenu suffisant pour un premier déploiement réel :

- Créer un projet Supabase réel et renseigner les variables d'environnement.
- Exécuter les migrations puis les seeds sur cette base réelle, dans l'ordre.
- Provisionner votre premier compte administrateur (procédure documentée dans `docs/DEPLOYMENT.md`).
- Renseigner un numéro Mobile Money / Orange Money / Moov Money réel avant d'ouvrir de vraies inscriptions Premium — le champ est aujourd'hui vide.
- Héberger l'application (Vercel recommandé) et configurer les variables d'environnement côté hébergeur.
- Vérifier le rendu du rapport PDF une première fois en conditions réelles (point de vigilance technique connu, lié à l'environnement serverless).
- Vérifier manuellement le mode hors connexion après déploiement (non testable automatiquement).
- Lancer le script de vérification des permissions (`verify_rls.sh`) avant tout déploiement touchant les règles d'accès — aucune vérification continue automatique n'est en place, cette étape doit être faite à la main.
- Faire un test manuel de bout en bout de l'application assemblée, une fois le contenu médical jugé suffisant.

## Un ordre possible

Rien n'oblige à suivre cet ordre, mais si vous cherchez par où continuer : la section 1 (exercices, programmes, règles d'attribution) est ce qui manque le plus pour qu'un patient reçoive quelque chose de concret — c'est probablement le chantier le plus impactant. Les sections 2 et 3 affinent et sécurisent ce qui existe déjà. La section 5 peut être menée en parallèle dès que vous voulez tester l'application dans des conditions réelles, même avec un contenu encore partiel.
