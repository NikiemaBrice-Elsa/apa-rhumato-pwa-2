# Feuille de route — ce qu'il reste avant une application pleinement fonctionnelle

Photographie au 21/08/2026. Le détail ligne par ligne reste à jour dans `docs/MEDICAL_VALIDATION_NEEDED.md` (contenu médical) et `docs/DECISIONS.md` (choix techniques, section « Ce qui n'est toujours pas fait » de chaque sprint) — ce document en est une synthèse organisée par priorité, pour répondre à « qu'est-ce qui reste, concrètement ».

## 1. Ce qui bloque aujourd'hui l'attribution d'un programme réel à un patient

C'est le point le plus important : même avec un dépistage vert fonctionnel, aucun patient ne reçoit aujourd'hui de programme concret, faute de trois éléments liés entre eux.

- **Bibliothèque d'exercices** : 8 exercices sourcés sur la littérature citée au §81, complétés par des propositions génériques (ACSM/Borg) explicitement demandées par vous. **Mise à jour du 23/08 (intégration) : validés et activés** (« Je valide. Tu peux les intégrer », `infra/db/seed/0011_exercises_validation_dr_nikiema_20260823.sql`) — `medical_validation_status = 'validated'`, désormais visibles côté client authentifié.
- **Contenu des programmes** : chaque combinaison pathologie × niveau (débutant/intermédiaire/avancé) a désormais une fiche FITT-VP complète (fréquence, intensité, temps, type, volume, progression), rédigée à partir des 10 références du §81 et complétée par des propositions génériques que vous avez explicitement demandées et validées. **Mise à jour du 23/08 (intégration) : les 18 programmes sont validés et activés** (`infra/db/seed/0012_programs_validation_dr_nikiema_20260823.sql`) — `medical_validation_status = 'validated'`, désormais visibles côté client authentifié.
- **Règles d'attribution (`allow_program`)** : le moteur qui décide quel programme proposer selon le dépistage, le niveau et la douleur est prêt et testé. **Mise à jour du 23/08 (finalisation) : les 18 règles réelles sont maintenant actives**, à partir de vos réponses à `QUESTIONS_ALLOW_PROGRAM_20260823.docx` (`infra/db/seed/0013_allow_program_rules_dr_nikiema_20260823.sql`) — le niveau initial est calculé automatiquement à partir de votre niveau d'activité déclaré, plafonné à débutant en cas de dépistage orange, comme vous l'avez précisé.

**Les trois éléments de cette section sont désormais tous en place et validés (23/08/2026).** Un patient authentifié qui complète une évaluation initiale peut maintenant recevoir un programme réel de façon entièrement automatique, dans le respect des garanties de sécurité que vous avez validées (rouge bloque tout ; orange plafonne au plus prudent).

## 2. Sécurité du dépistage — désormais close

Le dépistage de sécurité (vert/orange/rouge) est aujourd'hui fonctionnel pour les six pathologies, et les deux derniers points légers sont désormais réglés :

- **Relecture formelle des nouveaux messages** (issus de vos réponses Q2 à Q6, 21/08/2026) : soumise le 23/08/2026 (`RELECTURE_MESSAGES_Q2_Q6_20260823.docx`). **Mise à jour du 31/08 : validée sans correction** (« PAS DE CORRECTION A APPORTER ; TU PEUX INTEGRER ») — les 7 messages sont définitivement actifs tels quels.
- **Règles de progression/régression réelles** (`adjust_progression`) : les 4 points soumis le 23/08/2026 (`QUESTIONS_PROGRESSION_REGRESSION_20260823.docx`) ont reçu une réponse complète le 31/08. **Mise à jour du 31/08 : 24 règles réelles sont désormais actives** (une par décision × 6 pathologies) et affichées, en lecture seule, sur la page « Mes statistiques » — un bouton de bascule de niveau n'apparaît que lorsque la recommandation est « progresser », et reste une action volontaire de votre part (jamais automatique).

## 3. Fonctionnalités que vous avez déjà décrites, et qui sont maintenant en place

Ces quatre points avaient chacun une réponse de votre part, nécessitant une évolution du produit (nouveaux écrans, nouveaux champs de base de données) au-delà du seul contenu :

- **Structure de séance** (échauffement / partie principale / retour au calme, réf. B8) : **mise à jour du 31/08 : close.** Les 8 exercices existants sont classés en « Partie principale » selon votre réponse à `QUESTIONS_SEANCE_CAPACITE_FONCTIONNELLE_20260830.docx` (Q1). Aucun exercice n'est classé échauffement/retour au calme — inventer ce contenu aurait été contraire à votre consigne explicite ; l'écran de séance affiche donc une « Partie principale » seule tant qu'un contenu réel de ce type ne vous a pas été soumis.
- **Capacité fonctionnelle** (PROMIS Physical Function + PSFS, réf. B10) : **mise à jour du 31/08 : close pour la V1.** Le PSFS est intégré et actif (page « Mes statistiques »). Votre réponse à la Question 2 (Proposition C) confirme que PROMIS reste différé : le PSFS est le seul instrument de capacité fonctionnelle de la V1, sans approximation de PROMIS à partir d'échelles génériques. PROMIS pourra être revisité si vous nous donnez accès à l'API officielle ou un formulaire court fixe.
- **« Séance du jour » planifiée** (réf. B11) : aujourd'hui, le tableau de bord renvoie simplement vers « Démarrer une séance », sans planification automatique ni fenêtre de réalisation. Cette fonctionnalité conditionne aussi une partie des cadences de notification que vous avez données (réf. B14).
- **Nouvelle formule d'adhésion** (réf. B13) : nécessite d'abord de faire évoluer le schéma des séances pour distinguer commencée / partielle / complète / reportée / annulée pour raison de sécurité.

## 4. Fonctionnalités prévues par le cahier des charges mais volontairement pas activées en V1

- Espace professionnel de santé pour consulter les rapports (§41) — prévu, pas encore ouvert.
- Envoi du rapport PDF par email, et historique des rapports déjà générés (aujourd'hui, chaque génération est à la demande, rien n'est conservé).
- Envoi réel de notifications push (aujourd'hui, les notifications existent uniquement dans l'application, pas en dehors).
- Passerelle de paiement réelle — le mécanisme actuel est une réconciliation manuelle (le patient transfère via Mobile Money et déclare la référence, un administrateur vérifie et confirme).
- Verrouillage de fonctionnalités derrière l'abonnement Premium — décision produit encore en attente de votre part, rien n'est verrouillé aujourd'hui.

## 5. Mise en production — indépendant du contenu médical

Ce sont des étapes techniques, à faire une fois que vous jugez le contenu suffisant pour un premier déploiement réel :

- Créer un projet Supabase réel et renseigner les variables d'environnement.
- Exécuter les migrations puis les seeds sur cette base réelle, dans l'ordre.
- Provisionner votre premier compte administrateur (procédure documentée dans `docs/DEPLOYMENT.md`).
- Renseigner un numéro Mobile Money / Orange Money / Moov Money réel avant d'ouvrir de vraies inscriptions Premium — le champ est aujourd'hui vide.
- Héberger l'application (Vercel recommandé) et configurer les variables d'environnement côté hébergeur.
- Vérifier le rendu du rapport PDF une première fois en conditions réelles (point de vigilance technique connu, lié à l'environnement serverless).
- Vérifier manuellement le mode hors connexion après déploiement (non testable automatiquement).
- Lancer le script de vérification des permissions (`verify_rls.sh`) avant tout déploiement touchant les règles d'accès — aucune vérification continue automatique n'est en place, cette étape doit être faite à la main.
- Faire un test manuel de bout en bout de l'application assemblée, une fois le contenu médical jugé suffisant.

## Un ordre possible

Rien n'oblige à suivre cet ordre. **Mise à jour du 23/08 : la section 1 est désormais entièrement close** — un patient peut recevoir un programme réel de bout en bout. **Mise à jour du 31/08 : les sections 2 et 3 sont également closes** (hors « séance du jour » planifiée et nouvelle formule d'adhésion, qui restent à développer). Si vous cherchez par où continuer : ces deux points de la section 3, ou la section 5 (mise en production), peuvent être menés dès que vous le souhaitez, même avec un contenu encore partiel.
