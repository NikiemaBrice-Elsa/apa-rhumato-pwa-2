# APA Rhumatologie — PWA

Application PWA d'accompagnement à l'Activité Physique Adaptée en rhumatologie.

- **Concepteur médical et scientifique** : Dr Wendtongo Brice Florent NIKIEMA, médecin rhumatologue
- **Document directeur** : cahier des charges V1.0 (voir `docs/`)
- **Statut** : Sprint 16 — complément de validation médicale et dépistage vert/orange réel (20/08/2026, sur demande explicite de Dr Nikiema de compléter la validation immédiatement plutôt que d'activer un correctif partiel : seuil de douleur harmonisé et activé sur 6 pathologies, dépistage genou/hanche/PR/spondyloarthrite axiale/ostéoporose considérablement enrichi — nouveau type d'item `select` à 3 niveaux, ~38 nouvelles règles actives, ~20 nouveaux tests dédiés —, `evaluateSafetyScreeningFromRules` désormais capable d'un vrai `vert`/`orange` (pas seulement `rouge`/`pending_validation`) strictement conditionné à une règle `require_precaution` active, et correction d'un bug de sécurité préexistant sur l'affichage des 11 red flags lombalgie ; voir `docs/DECISIONS.md` section « Sprint 16 » et `docs/MEDICAL_VALIDATION_NEEDED.md`), en plus du Sprint 15 — tests complets (§55, §56 : inventaire de la couverture de test existante confronté à la checklist du cahier des charges, quatre cas cliniques fictifs du §56 rassemblés dans un seul fichier, tests d'injection, et surtout un script permanent de vérification RLS — `infra/db/scripts/verify_rls.sh` — qui remplace la procédure manuelle jetable utilisée jusqu'ici), du paiement du Sprint 14 (§47, §48 : demande de plan premium, déclaration de transaction Mobile Money/Orange Money/Moov Money, confirmation manuelle par un administrateur qui active la souscription — aucune passerelle de paiement réelle intégrée), de l'administration du Sprint 13 (§42 : gestion utilisateurs/pathologies/exercices/programmes/règles cliniques/références scientifiques, tableau de bord §64, rapport scientifique interne §65, journal d'audit §45), du mode hors connexion du Sprint 12 (§54, §10), des notifications in-app du Sprint 11 (§39), du rapport PDF du Sprint 10 (§40, §71), des statistiques du Sprint 9 (§33), du suivi du Sprint 8 (§34-38), des séances guidées du Sprint 7 (§28, §69) et des acquis du Sprint 6bis (programmes, red flags sourcées, gabarit de seuils cliniques). Points encore ouverts : symptômes périphériques spondyloarthrite (F2), reformulation patient-facing des 11 items lombalgie (C1) et messages orange par module (B12) en préparation, critères de progression/structure de séance/capacité fonctionnelle restant à implémenter — voir `docs/MEDICAL_VALIDATION_NEEDED.md`

## Structure du monorepo

- `apps/web` — application Next.js (PWA, frontend + API routes)
- `packages/domain` — types et logique partagés (dont calcul IMC, validation)
- `packages/rules-engine` — moteur de règles médicales déterministe (dépistage + sélection de programme, Sprint 4/6)
- `packages/payment-service` — interface `PaymentService` et registre des fournisseurs (Orange Money, Moov Money, Mobile Money) pour de futures intégrations réelles (§47) ; le mécanisme de paiement V1 réellement utilisé est une réconciliation manuelle indépendante de ce package (voir Sprint 14 dans `docs/DECISIONS.md`)
- `packages/pdf-report` — génération de rapports PDF (§40, §71, Sprint 10)
- `infra/db` — migrations et données de référence (seed)
- `infra/env` — modèle de variables d'environnement
- `docs` — documentation du projet, y compris `ARCHITECTURE_TECHNIQUE_V1.md`

## Démarrage rapide

Voir `docs/DEPLOYMENT.md`.

## Règle absolue (§59 du cahier des charges)

Aucune recommandation médicale n'est inventée dans ce code. Les paramètres cliniques manquants sont marqués `TODO_MEDICAL_VALIDATION` / `MEDICAL_PARAMETER_REQUIRED` et ne bloquent pas le développement technique.
